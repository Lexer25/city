<?php defined('SYSPATH') OR die('No direct access allowed.');

return array
(
		'fb' => array(
				'type'			=> 'pdo',
				'connection'	=> array(
					//'dsn'		=> 'odbc:SDUO',
					//'dsn'		=> 'odbc:Kalibr',
					//'dsn'		=> 'odbc:Kalibr_25',
					'dsn'		=> 'odbc:HL',
					'charset'   => 'windows-1251',
					)
				),
	
);

