<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2026-04-01 00:17:54 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '=>' (T_DOUBLE_ARROW) ~ APPPATH\views\dashboard.php [ 52 ] in file:line
2026-04-01 00:17:54 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 00:18:27 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ')' ~ APPPATH\views\dashboard.php [ 52 ] in file:line
2026-04-01 00:18:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 00:27:03 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$res' (T_VARIABLE), expecting function (T_FUNCTION) ~ MODPATH\people\classes\Model\People.php [ 540 ] in file:line
2026-04-01 00:27:03 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 00:27:18 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '{', expecting '(' ~ MODPATH\people\classes\Model\People.php [ 541 ] in file:line
2026-04-01 00:27:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 00:28:21 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ''getPeopleWithoutCard'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' ~ APPPATH\classes\Controller\Dashboard.php [ 130 ] in file:line
2026-04-01 00:28:21 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 00:28:40 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:29:10 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:29:13 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:30:20 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:33:23 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:33:55 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:35:36 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:36:49 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:37:19 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:37:20 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:37:20 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:37:21 --- ERROR: Error getting getPeopleWithoutCard: Undefined variable: query in C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php:74
2026-04-01 00:39:41 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'return' (T_RETURN) ~ MODPATH\people\classes\Model\People.php [ 556 ] in file:line
2026-04-01 00:39:41 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 00:39:56 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'return' (T_RETURN) ~ MODPATH\people\classes\Model\People.php [ 556 ] in file:line
2026-04-01 00:39:56 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 08:03:16 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: date ~ MODPATH\people\classes\Model\People.php [ 518 ] in C:\xampp\htdocs\city\modules\people\classes\Model\People.php:518
2026-04-01 08:03:16 --- DEBUG: #0 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(518): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 518, Array)
#1 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(127): Model_People->getCountCardLateNextTime('01.05.2026')
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#3 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#9 {main} in C:\xampp\htdocs\city\modules\people\classes\Model\People.php:518
2026-04-01 08:20:53 --- CRITICAL: ErrorException [ 8 ]: Undefined index: people_count ~ APPPATH\views\dashboard.php [ 71 ] in C:\xampp\htdocs\city\application\views\dashboard.php:71
2026-04-01 08:20:53 --- DEBUG: #0 C:\xampp\htdocs\city\application\views\dashboard.php(71): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 71, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\application\views\template.php(111): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\application\views\dashboard.php:71
2026-04-01 08:50:14 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_Stat::getStatPeopleAndCard() ~ APPPATH\classes\Controller\Dashboard.php [ 68 ] in file:line
2026-04-01 08:50:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 08:53:11 --- CRITICAL: ErrorException [ 8 ]: Undefined index: card ~ APPPATH\views\dashboard.php [ 26 ] in C:\xampp\htdocs\city\application\views\dashboard.php:26
2026-04-01 08:53:11 --- DEBUG: #0 C:\xampp\htdocs\city\application\views\dashboard.php(26): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 26, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\application\views\template.php(111): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\application\views\dashboard.php:26
2026-04-01 08:55:28 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'endif' (T_ENDIF) ~ APPPATH\views\dashboard.php [ 84 ] in file:line
2026-04-01 08:55:28 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 08:55:48 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'endif' (T_ENDIF) ~ APPPATH\views\dashboard.php [ 84 ] in file:line
2026-04-01 08:55:48 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 08:56:30 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ' ~ APPPATH\views\dashboard.php [ 68 ] in file:line
2026-04-01 08:56:30 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 08:56:45 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'endif' (T_ENDIF) ~ APPPATH\views\dashboard.php [ 83 ] in file:line
2026-04-01 08:56:45 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-04-01 08:58:07 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ':' ~ APPPATH\views\dashboard.php [ 79 ] in file:line
2026-04-01 08:58:07 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line