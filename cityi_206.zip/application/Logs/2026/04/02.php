<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2026-04-02 21:00:37 --- CRITICAL: Database_Exception [ 0 ]: SQLSTATE[IM002] SQLConnect: 0 [Microsoft][��������� ��������� ODBC] �������� ������ �� ������ � �� ������ �������, ������������ �� ��������� ~ APPPATH\classes\Kohana\Database\PDO.php [ 61 ] in C:\xampp\htdocs\city\application\classes\Kohana\Database\PDO.php:138
2026-04-02 21:00:37 --- DEBUG: #0 C:\xampp\htdocs\city\application\classes\Kohana\Database\PDO.php(138): Kohana_Database_PDO->connect()
#1 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, 'select cdx.id_d...', false, Array)
#2 C:\xampp\htdocs\city\modules\dev\classes\Model\Dev.php(105): Kohana_Database_Query->execute(Object(Database_PDO))
#3 C:\xampp\htdocs\city\modules\dev\classes\Model\Dev.php(44): Model_Dev->getCardidxStat()
#4 C:\xampp\htdocs\city\modules\dev\classes\controller\Dev.php(34): Model_Dev->getDataList()
#5 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dev->action_load()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#10 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#11 {main} in C:\xampp\htdocs\city\application\classes\Kohana\Database\PDO.php:138
2026-04-02 21:01:41 --- CRITICAL: Database_Exception [ 0 ]: SQLSTATE[IM002] SQLConnect: 0 [Microsoft][��������� ��������� ODBC] �������� ������ �� ������ � �� ������ �������, ������������ �� ��������� ~ APPPATH\classes\Kohana\Database\PDO.php [ 61 ] in C:\xampp\htdocs\city\application\classes\Kohana\Database\PDO.php:138
2026-04-02 21:01:41 --- DEBUG: #0 C:\xampp\htdocs\city\application\classes\Kohana\Database\PDO.php(138): Kohana_Database_PDO->connect()
#1 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, 'select cdx.id_d...', false, Array)
#2 C:\xampp\htdocs\city\modules\dev\classes\Model\Dev.php(105): Kohana_Database_Query->execute(Object(Database_PDO))
#3 C:\xampp\htdocs\city\modules\dev\classes\Model\Dev.php(44): Model_Dev->getCardidxStat()
#4 C:\xampp\htdocs\city\modules\dev\classes\controller\Dev.php(34): Model_Dev->getDataList()
#5 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dev->action_load()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#10 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#11 {main} in C:\xampp\htdocs\city\application\classes\Kohana\Database\PDO.php:138