<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2026-03-31 14:04:38 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ' ~ MODPATH\parsec\views\Parsec\parsec.php [ 4 ] in file:line
2026-03-31 14:04:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:15:06 --- CRITICAL: ErrorException [ 2 ]: _() expects exactly 1 parameter, 2 given ~ APPPATH\views\dashboard.php [ 49 ] in file:line
2026-03-31 22:15:06 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, '_() expects exa...', 'C:\\xampp\\htdocs...', 49, Array)
#1 C:\xampp\htdocs\city\application\views\dashboard.php(49): _('\xD0\x9A\xD0\xBE\xD0\xBB\xD0\xB8\xD1\x87\xD0\xB5\xD1\x81\xD1...', Array)
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#4 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#5 C:\xampp\htdocs\city\application\views\template.php(111): Kohana_View->__toString()
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#7 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#9 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#14 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#15 {main} in file:line
2026-03-31 22:16:23 --- CRITICAL: ErrorException [ 2 ]: _() expects exactly 1 parameter, 2 given ~ APPPATH\views\dashboard.php [ 49 ] in file:line
2026-03-31 22:16:23 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, '_() expects exa...', 'C:\\xampp\\htdocs...', 49, Array)
#1 C:\xampp\htdocs\city\application\views\dashboard.php(49): _('\xD0\x9A\xD0\xBE\xD0\xBB\xD0\xB8\xD1\x87\xD0\xB5\xD1\x81\xD1...', Array)
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#4 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#5 C:\xampp\htdocs\city\application\views\template.php(111): Kohana_View->__toString()
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#7 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#9 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#14 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#15 {main} in file:line
2026-03-31 22:31:42 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '}' ~ APPPATH\classes\Controller\Dashboard.php [ 120 ] in file:line
2026-03-31 22:31:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:32:00 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_People::getPeopleCount() ~ APPPATH\classes\Controller\Dashboard.php [ 117 ] in file:line
2026-03-31 22:32:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:35:00 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Model_People::getPeopleCount() ~ APPPATH\classes\Controller\Dashboard.php [ 117 ] in file:line
2026-03-31 22:35:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:41:13 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\views\dashboard.php [ 51 ] in file:line
2026-03-31 22:41:13 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:41:41 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\views\dashboard.php [ 52 ] in file:line
2026-03-31 22:41:41 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:49:19 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '(', expecting ')' ~ MODPATH\people\classes\Model\People.php [ 504 ] in file:line
2026-03-31 22:49:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:49:31 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '(', expecting ')' ~ MODPATH\people\classes\Model\People.php [ 504 ] in file:line
2026-03-31 22:49:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:50:07 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '(', expecting ')' ~ MODPATH\people\classes\Model\People.php [ 504 ] in file:line
2026-03-31 22:50:07 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:51:56 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$date' (T_VARIABLE) ~ MODPATH\people\classes\Model\People.php [ 506 ] in file:line
2026-03-31 22:51:56 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-31 22:59:21 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 1, char 20. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ SELECT COUNT(*) AS count FROM card WHERE timeend > NOW() AND timeend < ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 22:59:21 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, 'SELECT COUNT(*)...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(524): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 22:59:54 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 1, char 20. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ SELECT COUNT(*) AS count FROM card WHERE timeend < ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 22:59:54 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, 'SELECT COUNT(*)...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(523): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:00:21 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 2, char 25. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ 
					SELECT COUNT(*) as count 
					FROM card c 
					WHERE c.timeend > NOW() 
					  AND c.timeend < NOW() + INTERVAL '30 days'
				 ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:00:21 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, '\r\n\t\t\t\t\tSELECT C...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(523): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:02:25 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 2, char 25. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ 
					SELECT COUNT(*) as count 
					FROM card c 
					WHERE c.timeend < 
				 ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:02:25 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, '\r\n\t\t\t\t\tSELECT C...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(525): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:03:34 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 2, char 25. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ 
					SELECT COUNT(*) as count 
					FROM card c 
					WHERE c.timeend < 
				 ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:03:34 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, '\r\n\t\t\t\t\tSELECT C...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(526): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:04:15 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 2, char 25. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ 
					SELECT COUNT(*) as count 
					FROM card c 
					WHERE c.timeend < CAST( AS TIMESTAMP)
				 ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:04:15 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, '\r\n\t\t\t\t\tSELECT C...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(525): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:04:33 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 2, char 25. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ 
					SELECT COUNT(*) as count 
					FROM card c 
					WHERE c.timeend < 
				 ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:04:33 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, '\r\n\t\t\t\t\tSELECT C...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(525): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:05:25 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 1, char 20. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ SELECT COUNT(*) as count FROM card c WHERE c.timeend < CAST('2026-04-30 23:05:25' AS TIMESTAMP) ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:05:25 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, 'SELECT COUNT(*)...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(521): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:06:28 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 4, char 30. AS.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ 
					SELECT COUNT(*) 
					FROM card c 
					WHERE c.timeend < CAST( AS TIMESTAMP)
				 ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:06:28 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, '\r\n\t\t\t\t\tSELECT C...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(525): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:06:47 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 4, char 30. AS.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ 
					SELECT COUNT(*) 
					FROM card c 
					WHERE c.timeend < CAST( AS TIMESTAMP)
				 ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:06:47 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, '\r\n\t\t\t\t\tSELECT C...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(525): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:07:15 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 1, char 20. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ SELECT COUNT(*) as count FROM card c WHERE c.timeend < CAST('2026-04-30 23:07:15' AS TIMESTAMP) ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:07:15 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, 'SELECT COUNT(*)...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(521): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:07:54 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 1, char 20. count.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ SELECT COUNT(*) as count FROM card c WHERE c.timeend < CAST('2026-04-30 23:07:54' AS TIMESTAMP) ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-03-31 23:07:54 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, 'SELECT COUNT(*)...', false, Array)
#1 C:\xampp\htdocs\city\modules\people\classes\Model\People.php(521): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(122): Model_People->getCountCardLateNextTime(30)
#3 C:\xampp\htdocs\city\application\classes\Controller\Dashboard.php(74): Controller_Dashboard->getWin1()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251