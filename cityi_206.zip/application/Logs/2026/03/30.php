<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2026-03-30 08:13:52 --- DEBUG: 62 identifier::action_control - POST: Array
(
    [page] => 1
    [event_date] => 2025-08-01
    [todo] => allCards
)
 in C:\xampp\htdocs\city\system\classes\Kohana\Controller.php:84
2026-03-30 08:14:15 --- CRITICAL: ErrorException [ 1 ]: Allowed memory size of 134217728 bytes exhausted (tried to allocate 78212657 bytes) ~ SYSPATH\classes\Kohana\View.php [ 74 ] in file:line
2026-03-30 08:14:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 08:15:34 --- DEBUG: 62 identifier::action_control - POST: Array
(
    [page] => 1
    [event_date] => 2025-08-01
    [todo] => allCards
)
 in C:\xampp\htdocs\city\system\classes\Kohana\Controller.php:84
2026-03-30 08:55:02 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ''guide'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' ~ APPPATH\views\top_menu.php [ 102 ] in file:line
2026-03-30 08:55:02 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 08:58:10 --- CRITICAL: ErrorException [ 1 ]: Class 'DB' not found ~ APPPATH\classes\Auth\File.php [ 30 ] in file:line
2026-03-30 08:58:10 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 08:58:51 --- CRITICAL: ErrorException [ 1 ]: Class 'Database' not found ~ APPPATH\classes\Controller\Check_db_connect.php [ 5 ] in file:line
2026-03-30 08:58:51 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 08:59:52 --- CRITICAL: ErrorException [ 1 ]: Class 'DB' not found ~ APPPATH\classes\Auth\File.php [ 30 ] in file:line
2026-03-30 08:59:52 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:00:16 --- CRITICAL: ErrorException [ 1 ]: Class 'Database' not found ~ APPPATH\classes\Controller\Check_db_connect.php [ 5 ] in file:line
2026-03-30 09:00:16 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:06:12 --- CRITICAL: ErrorException [ 1 ]: Class 'Database' not found ~ APPPATH\classes\Controller\Check_db_connect.php [ 5 ] in file:line
2026-03-30 09:06:12 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:06:56 --- CRITICAL: ErrorException [ 1 ]: Class 'Database' not found ~ APPPATH\classes\Controller\Check_db_connect.php [ 5 ] in file:line
2026-03-30 09:06:56 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:07:15 --- CRITICAL: ErrorException [ 1 ]: Class 'Database' not found ~ APPPATH\classes\Controller\Check_db_connect.php [ 5 ] in file:line
2026-03-30 09:07:15 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:07:17 --- CRITICAL: ErrorException [ 1 ]: Class 'Database' not found ~ APPPATH\classes\Controller\Check_db_connect.php [ 5 ] in file:line
2026-03-30 09:07:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:08:24 --- CRITICAL: ErrorException [ 1 ]: Class 'Database' not found ~ APPPATH\classes\Controller\Check_db_connect.php [ 5 ] in file:line
2026-03-30 09:08:24 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:10:57 --- CRITICAL: Kohana_Exception [ 0 ]: Attempted to load an invalid or missing module 'about' at 'MODPATH\about' ~ SYSPATH\classes\Kohana\Core.php [ 579 ] in C:\xampp\htdocs\city\application\bootstrap.php:149
2026-03-30 09:10:57 --- DEBUG: #0 C:\xampp\htdocs\city\application\bootstrap.php(149): Kohana_Core::modules(Array)
#1 C:\xampp\htdocs\city\index.php(102): require('C:\\xampp\\htdocs...')
#2 {main} in C:\xampp\htdocs\city\application\bootstrap.php:149
2026-03-30 09:13:13 --- CRITICAL: ErrorException [ 1 ]: Class 'Database' not found ~ APPPATH\classes\Controller\Check_db_connect.php [ 5 ] in file:line
2026-03-30 09:13:13 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:13:49 --- CRITICAL: ErrorException [ 1 ]: Class 'DB' not found ~ APPPATH\classes\Auth\File.php [ 30 ] in file:line
2026-03-30 09:13:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:24:38 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ''website_2'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' ~ MODPATH\about\classes\Controller\About.php [ 23 ] in file:line
2026-03-30 09:24:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-03-30 09:24:46 --- CRITICAL: ErrorException [ 8 ]: Undefined index: website ~ MODPATH\about\views\about\index.php [ 22 ] in C:\xampp\htdocs\city\modules\about\views\about\index.php:22
2026-03-30 09:24:46 --- DEBUG: #0 C:\xampp\htdocs\city\modules\about\views\about\index.php(22): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 22, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\application\views\template.php(111): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_About))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\about\views\about\index.php:22
2026-03-30 09:26:20 --- CRITICAL: ErrorException [ 8 ]: Undefined index: website ~ MODPATH\about\views\about\index.php [ 22 ] in C:\xampp\htdocs\city\modules\about\views\about\index.php:22
2026-03-30 09:26:20 --- DEBUG: #0 C:\xampp\htdocs\city\modules\about\views\about\index.php(22): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 22, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\application\views\template.php(111): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_About))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\about\views\about\index.php:22