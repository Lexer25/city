<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2026-01-07 09:30:46 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 1, char 31. ,.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ select d.id_dev, d.id_devtype,, d.id_reader, d.name, d.netaddr, d."ACTIVE", d2.id_dev as parentId, d2.name as parentName,  s.id_server, s.name as serverName, std.facts as dbCount from device d
        join device d2 on d2.id_ctrl=d.id_ctrl and d2.id_reader is null
        left join server s on d2.id_server=s.id_server
        left join st_data std on d.id_dev=std.id_dev and std.id_param in (8)
        where d.id_reader is not null
        order by d.id_dev ] ~ APPPATH\classes\Kohana\Database\PDO.php [ 159 ] in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-01-07 09:30:46 --- DEBUG: #0 C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(1, 'select d.id_dev...', false, Array)
#1 C:\xampp\htdocs\city\modules\dev\classes\Model\Dev.php(45): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\city\modules\dev\classes\Controller\Dev.php(39): Model_Dev->getDevDataDetail()
#3 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dev->action_load()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#9 {main} in C:\xampp\htdocs\city\modules\database\classes\Kohana\Database\Query.php:251
2026-01-07 09:51:11 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ MODPATH\dev\views\load_table_new2.php [ 70 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:70
2026-01-07 09:51:11 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(70): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\xampp\\htdocs...', 70, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dev\views\load_table_new.php(58): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#8 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#9 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#10 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#11 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#12 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#13 [internal function]: Kohana_Controller->execute()
#14 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#15 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#16 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#17 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#18 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:70
2026-01-07 11:09:24 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: door ~ MODPATH\dev\views\load_table_new2.php [ 55 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:55
2026-01-07 11:09:24 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(55): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 55, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dev\views\load_table_new.php(58): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#8 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#9 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#10 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#11 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#12 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#13 [internal function]: Kohana_Controller->execute()
#14 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#15 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#16 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#17 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#18 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:55
2026-01-07 11:14:43 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: deltacard ~ MODPATH\dev\views\load_table_new2.php [ 76 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:76
2026-01-07 11:14:43 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(76): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 76, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dev\views\load_table_new.php(58): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#8 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#9 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#10 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#11 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#12 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#13 [internal function]: Kohana_Controller->execute()
#14 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#15 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#16 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#17 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#18 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:76
2026-01-07 11:33:40 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'iconv' (T_STRING), expecting ',' or ';' ~ MODPATH\dev\views\load_table_new2.php [ 86 ] in file:line
2026-01-07 11:33:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 11:37:35 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '.' ~ MODPATH\dev\views\load_table_new2.php [ 91 ] in file:line
2026-01-07 11:37:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 12:18:37 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '.' ~ MODPATH\dev\views\load_table_new2.php [ 93 ] in file:line
2026-01-07 12:18:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 12:30:34 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '.' ~ MODPATH\dev\views\load_table_new2.php [ 112 ] in file:line
2026-01-07 12:30:34 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 12:31:05 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '.' ~ MODPATH\dev\views\load_table_new2.php [ 113 ] in file:line
2026-01-07 12:31:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 12:31:20 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '.' ~ MODPATH\dev\views\load_table_new2.php [ 113 ] in file:line
2026-01-07 12:31:20 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 14:20:22 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'else' (T_ELSE) ~ MODPATH\dev\views\load_table_new2.php [ 178 ] in file:line
2026-01-07 14:20:22 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 14:20:37 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'else' (T_ELSE) ~ MODPATH\dev\views\load_table_new2.php [ 178 ] in file:line
2026-01-07 14:20:37 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 14:31:11 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected end of file ~ MODPATH\dev\views\load_table_new2.php [ 317 ] in file:line
2026-01-07 14:31:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 14:34:26 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: collectAttention ~ MODPATH\dev\views\load_table_new2.php [ 291 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:291
2026-01-07 14:34:26 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(291): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 291, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dev\views\load_table_new.php(58): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#8 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#9 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#10 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#11 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#12 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#13 [internal function]: Kohana_Controller->execute()
#14 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#15 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#16 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#17 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#18 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:291
2026-01-07 14:35:26 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: deltacard ~ MODPATH\dev\views\load_table_new2.php [ 83 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:83
2026-01-07 14:35:26 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(83): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 83, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dev\views\load_table_new.php(58): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#8 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#9 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#10 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#11 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#12 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#13 [internal function]: Kohana_Controller->execute()
#14 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#15 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#16 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#17 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#18 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:83
2026-01-07 20:51:10 --- CRITICAL: ErrorException [ 2 ]: Creating default object from empty value ~ MODPATH\dev\classes\Model\Dev.php [ 32 ] in C:\xampp\htdocs\city\modules\dev\classes\Model\Dev.php:32
2026-01-07 20:51:10 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\classes\Model\Dev.php(32): Kohana_Core::error_handler(2, 'Creating defaul...', 'C:\\xampp\\htdocs...', 32, Array)
#1 C:\xampp\htdocs\city\modules\dev\classes\Controller\Dev.php(35): Model_Dev->getDataList()
#2 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dev->action_load()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#5 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\city\modules\dev\classes\Model\Dev.php:32
2026-01-07 20:51:35 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting variable (T_VARIABLE) or '$' ~ MODPATH\dev\classes\Model\Dev.php [ 32 ] in file:line
2026-01-07 20:51:35 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 20:55:18 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '=>' (T_DOUBLE_ARROW) ~ MODPATH\dev\classes\Model\Dev.php [ 52 ] in file:line
2026-01-07 20:55:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 20:56:06 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$deviceInfo' (T_VARIABLE) ~ MODPATH\dev\classes\Model\Dev.php [ 53 ] in file:line
2026-01-07 20:56:06 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 20:56:23 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '"483"' (T_CONSTANT_ENCAPSED_STRING) ~ MODPATH\dev\classes\Model\Dev.php [ 56 ] in file:line
2026-01-07 20:56:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 20:56:38 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'FALSE' (T_STRING) ~ MODPATH\dev\classes\Model\Dev.php [ 57 ] in file:line
2026-01-07 20:56:38 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 20:56:40 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'FALSE' (T_STRING) ~ MODPATH\dev\classes\Model\Dev.php [ 57 ] in file:line
2026-01-07 20:56:40 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 21:02:34 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: doorMode ~ MODPATH\dev\views\load_table_new2.php [ 68 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:68
2026-01-07 21:02:34 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(68): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 68, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:68
2026-01-07 21:03:57 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '==' (T_IS_EQUAL), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' ~ MODPATH\dev\views\load_table_new2.php [ 93 ] in file:line
2026-01-07 21:03:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 21:04:16 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 53 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:53
2026-01-07 21:04:16 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(53): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 53, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:53
2026-01-07 21:04:33 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 56 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:56
2026-01-07 21:04:33 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(56): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 56, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:56
2026-01-07 21:04:46 --- CRITICAL: ErrorException [ 8 ]: Undefined property: DeviceInfo::$doorMode ~ MODPATH\dev\views\load_table_new2.php [ 73 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:73
2026-01-07 21:04:46 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(73): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\\xampp\\htdocs...', 73, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:73
2026-01-07 21:06:05 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 80 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:80
2026-01-07 21:06:05 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(80): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 80, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:80
2026-01-07 21:07:43 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 81 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:81
2026-01-07 21:07:43 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(81): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 81, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:81
2026-01-07 21:09:37 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 87 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:87
2026-01-07 21:09:37 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(87): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 87, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:87
2026-01-07 21:10:46 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 97 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:97
2026-01-07 21:10:46 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(97): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 97, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:97
2026-01-07 21:11:15 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 97 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:97
2026-01-07 21:11:15 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(97): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 97, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:97
2026-01-07 21:11:33 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 142 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:142
2026-01-07 21:11:33 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(142): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 142, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:142
2026-01-07 21:12:33 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 150 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:150
2026-01-07 21:12:33 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(150): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 150, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:150
2026-01-07 21:13:22 --- CRITICAL: ErrorException [ 8 ]: Undefined property: DeviceInfo::$id_reader ~ MODPATH\dev\views\load_table_new2.php [ 151 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:151
2026-01-07 21:13:22 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(151): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\\xampp\\htdocs...', 151, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:151
2026-01-07 21:13:56 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: value ~ MODPATH\dev\views\load_table_new2.php [ 159 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:159
2026-01-07 21:13:56 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(159): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 159, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:159
2026-01-07 21:14:27 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ')', expecting ',' or ';' ~ MODPATH\dev\views\load_table_new2.php [ 159 ] in file:line
2026-01-07 21:14:27 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2026-01-07 21:14:35 --- CRITICAL: ErrorException [ 8 ]: Undefined property: DeviceInfo::$doorname ~ MODPATH\dev\views\load_table_new2.php [ 159 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:159
2026-01-07 21:14:35 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(159): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\\xampp\\htdocs...', 159, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:159
2026-01-07 21:14:57 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: doorMode ~ MODPATH\dev\views\load_table_new2.php [ 183 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:183
2026-01-07 21:14:57 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(183): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 183, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:183
2026-01-07 21:16:01 --- CRITICAL: ErrorException [ 8 ]: Undefined property: DeviceInfo::$id_dev ~ MODPATH\dev\views\load_table_new2.php [ 143 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:143
2026-01-07 21:16:01 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(143): Kohana_Core::error_handler(8, 'Undefined prope...', 'C:\\xampp\\htdocs...', 143, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:143
2026-01-07 21:23:06 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: collectAttention ~ MODPATH\dev\views\load_table_new2.php [ 67 ] in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:67
2026-01-07 21:23:06 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php(67): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 67, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\city\modules\dashboard\views\template_width.php(68): Kohana_View->__toString()
#5 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dev))
#11 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\city\modules\dev\views\load_table_new2.php:67
2026-01-07 21:28:42 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ MODPATH\dev\classes\Model\Dev.php [ 86 ] in file:line
2026-01-07 21:28:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line