<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2025-12-29 22:10:25 --- CRITICAL: ErrorException [ 1 ]: Call to undefined method Controller_Dev::getErrArrForDevice() ~ MODPATH\dev\classes\controller\Dev.php [ 63 ] in file:line
2025-12-29 22:10:25 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2025-12-29 22:11:55 --- DEBUG: 229 curl нет связи 192.168.0.33 in C:\xampp\htdocs\city\application\classes\artonitHTTP.php:59
2025-12-29 22:18:01 --- DEBUG: 229 curl нет связи 192.168.0.33 in C:\xampp\htdocs\city\application\classes\artonitHTTP.php:59
2025-12-29 22:25:58 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: res ~ MODPATH\apb\classes\Model\Apb.php [ 112 ] in C:\xampp\htdocs\city\modules\apb\classes\Model\Apb.php:112
2025-12-29 22:25:58 --- DEBUG: #0 C:\xampp\htdocs\city\modules\apb\classes\Model\Apb.php(112): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 112, Array)
#1 C:\xampp\htdocs\city\modules\apb\classes\Controller\Apb.php(21): Model_Apb->get_list()
#2 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Apb->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Apb))
#5 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\city\modules\apb\classes\Model\Apb.php:112
2025-12-29 22:26:03 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: res ~ MODPATH\apb\classes\Model\Apb.php [ 112 ] in C:\xampp\htdocs\city\modules\apb\classes\Model\Apb.php:112
2025-12-29 22:26:03 --- DEBUG: #0 C:\xampp\htdocs\city\modules\apb\classes\Model\Apb.php(112): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 112, Array)
#1 C:\xampp\htdocs\city\modules\apb\classes\Controller\Apb.php(21): Model_Apb->get_list()
#2 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Apb->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Apb))
#5 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\city\modules\apb\classes\Model\Apb.php:112
2025-12-29 23:12:32 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: _connectName ~ MODPATH\dashboard\classes\controller\Dashboard.php [ 84 ] in C:\xampp\htdocs\city\modules\dashboard\classes\controller\Dashboard.php:84
2025-12-29 23:12:32 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dashboard\classes\controller\Dashboard.php(84): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 84, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#4 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\city\modules\dashboard\classes\controller\Dashboard.php:84
2025-12-29 23:12:42 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: _connectName ~ MODPATH\dashboard\classes\controller\Dashboard.php [ 84 ] in C:\xampp\htdocs\city\modules\dashboard\classes\controller\Dashboard.php:84
2025-12-29 23:12:42 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dashboard\classes\controller\Dashboard.php(84): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 84, Array)
#1 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#4 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\city\modules\dashboard\classes\controller\Dashboard.php:84
2025-12-29 23:15:08 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: about ~ MODPATH\dashboard\views\top_menu.php [ 93 ] in C:\xampp\htdocs\city\modules\dashboard\views\top_menu.php:93
2025-12-29 23:15:08 --- DEBUG: #0 C:\xampp\htdocs\city\modules\dashboard\views\top_menu.php(93): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 93, Array)
#1 C:\xampp\htdocs\city\modules\dashboard\views\template.php(68): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\city\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#3 C:\xampp\htdocs\city\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#4 C:\xampp\htdocs\city\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#5 C:\xampp\htdocs\city\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#6 [internal function]: Kohana_Controller->execute()
#7 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#8 C:\xampp\htdocs\city\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 C:\xampp\htdocs\city\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#10 C:\xampp\htdocs\city\index.php(118): Kohana_Request->execute()
#11 {main} in C:\xampp\htdocs\city\modules\dashboard\views\top_menu.php:93
2025-12-29 23:37:42 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'PRIMARY' (T_STRING) ~ MODPATH\dashboard\classes\Model\Parkdb.php [ 59 ] in file:line
2025-12-29 23:37:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2025-12-29 23:43:31 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '.' ~ MODPATH\dashboard\views\dashboard.php [ 88 ] in file:line
2025-12-29 23:43:31 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2025-12-29 23:50:46 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ MODPATH\dashboard\views\dashboard.php [ 122 ] in file:line
2025-12-29 23:50:46 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line