<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2025-12-30 08:21:01 --- DEBUG: Synctime for device :92 in C:\xampp\htdocs\city\system\classes\Kohana\Controller.php:84
2025-12-30 08:21:01 --- DEBUG: Device Read device time command: 192.168.10.108, 1967, 8.1 -1 этаж (2), getdevicetime in C:\xampp\htdocs\city\modules\dev\classes\controller\Dev.php:162